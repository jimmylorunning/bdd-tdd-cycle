require 'spec_helper'

describe MoviesController do

	describe 'similar -- ' do
		context "happy path" do

			it 'should call a RESTFUL route' do
				expect(:get => '/movies/3/similar').to route_to(
					:controller => "movies",
					:action => "similar",
					:id => "3"
				)
			end

			it "should grab the id of the movie" do
				Movie.stub(:movies_with_same_director)
				Movie.stub(:find)
				get :similar, {:id => '1'}
				assigns(:id).should == '1'
			end

			it "should ask model for movies with same director" do
				fake_movies = [double("Blade Runner"), double("Prometheus")]
				Movie.should_receive(:movies_with_same_director).with('1').and_return(fake_movies)
				get :similar, {:id => '1'}
				assigns(:movies).should == fake_movies
			end

		end

		context "sad paths" do

			it "should redirect with flash message if current movie has no director info" do
				@m1 = FactoryGirl.create(:movie, :id => 1, :title => 'Alien', :director => 'Scott')
				Movie.stub(:find).and_return(@m1)
				Movie.should_receive(:movies_with_same_director).with('1').and_return(nil)
				get :similar, {:id => '1'}
				flash.should_not be_nil
				response.should redirect_to movies_path
			end

		end

	end

end
